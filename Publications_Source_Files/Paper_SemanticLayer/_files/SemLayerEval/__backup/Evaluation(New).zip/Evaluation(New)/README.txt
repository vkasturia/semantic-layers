The evaluation files contain the results returned by the SPARQL endpoint and the search systems Google and HistDiv.

There are 3 result files (SPARQL, Google and HistDiv) preceded by query no. for each of the 20 queries.

The result files contain the following columns:

URL: Link to the New York Times(NYT) article   
TITLE: Title of the NYT Article
RELEVANT?: Whether result is relevant or not
EXPLANATION: Explanation for relevance or irrelevance of result

All the entries are tab (\t) separated. 

In case the system did not return any result the .result files contain the following:
# NO RESULTS RETURNED BY SYSTEM_NAME FOR THIS QUERY
